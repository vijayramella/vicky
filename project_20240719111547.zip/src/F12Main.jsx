const tableHeaderStyle = {
  backgroundColor: "#f2f2f2",
  padding: 8,
  border: "1px solid #ddd",
}

const tableCellStyle = {
  padding: 8,
  border: "1px solid #ddd",
  color: "blue",
}

export default function F12Main() {
  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ marginBottom: 20, fontSize: 20 }}>Page List</h1>
      <table style={{ borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr>
            <th style={tableHeaderStyle}>URL</th>
            <th style={tableHeaderStyle}>Page</th>
          </tr>
        </thead>
        <tbody>
<tr>
            <td style={tableCellStyle}><a href='/Column2'>/Column2</a></td>
            <td style={tableCellStyle}><a href='/Column2'>column2?</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Column3'>/Column3</a></td>
            <td style={tableCellStyle}><a href='/Column3'>column3?</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame20'>/Frame20</a></td>
            <td style={tableCellStyle}><a href='/Frame20'>Frame 20</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Frame21'>/Frame21</a></td>
            <td style={tableCellStyle}><a href='/Frame21'>Frame 21</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default'>/Property1Default</a></td>
            <td style={tableCellStyle}><a href='/Property1Default'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/Property1Default1'>/Property1Default1</a></td>
            <td style={tableCellStyle}><a href='/Property1Default1'>Property 1=Default</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/RimoonClearLine'>/RimoonClearLine</a></td>
            <td style={tableCellStyle}><a href='/RimoonClearLine'>ri:moon-clear-line</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoEditlistDark'>/ToDoEditlistDark</a></td>
            <td style={tableCellStyle}><a href='/ToDoEditlistDark'>TO DO + edit/list-dark</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoEditlistLight'>/ToDoEditlistLight</a></td>
            <td style={tableCellStyle}><a href='/ToDoEditlistLight'>TO DO + edit/list-light</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoNavEditlistDark'>/ToDoNavEditlistDark</a></td>
            <td style={tableCellStyle}><a href='/ToDoNavEditlistDark'>TO DO + Nav + edit/list-dark</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoNavEditlistLight'>/ToDoNavEditlistLight</a></td>
            <td style={tableCellStyle}><a href='/ToDoNavEditlistLight'>TO DO + Nav + edit/list-light</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoNavblockDark'>/ToDoNavblockDark</a></td>
            <td style={tableCellStyle}><a href='/ToDoNavblockDark'>TO DO + Nav/block-dark</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoNavblockLight'>/ToDoNavblockLight</a></td>
            <td style={tableCellStyle}><a href='/ToDoNavblockLight'>TO DO + Nav/block-light</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoNavlistDark'>/ToDoNavlistDark</a></td>
            <td style={tableCellStyle}><a href='/ToDoNavlistDark'>TO DO + Nav/list-dark</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoNavlistLight'>/ToDoNavlistLight</a></td>
            <td style={tableCellStyle}><a href='/ToDoNavlistLight'>TO DO + Nav/list-light</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoblockDark'>/ToDoblockDark</a></td>
            <td style={tableCellStyle}><a href='/ToDoblockDark'>TO DO /block-dark</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDoblockLight'>/ToDoblockLight</a></td>
            <td style={tableCellStyle}><a href='/ToDoblockLight'>TO DO /block-light</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDolistDark'>/ToDolistDark</a></td>
            <td style={tableCellStyle}><a href='/ToDolistDark'>TO DO /list-dark</a></td>
          </tr>
<tr>
            <td style={tableCellStyle}><a href='/ToDolistLight'>/ToDolistLight</a></td>
            <td style={tableCellStyle}><a href='/ToDolistLight'>TO DO /list-light</a></td>
          </tr>
</tbody>
      </table>
    </div>
  );
}