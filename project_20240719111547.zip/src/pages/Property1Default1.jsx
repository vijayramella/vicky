import './Property1Default1.css'

export default function Property1Default1() {
  return (
    <div className="property-1-default">
      <div className="ageneric-user-avatar-with-asimple-design">
      </div>
    </div>
  )
}