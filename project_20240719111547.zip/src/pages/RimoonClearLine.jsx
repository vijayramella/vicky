import './RimoonClearLine.css'

export default function RimoonClearLine() {
  return (
    <div className="rimoon-clear-line">
      <img className="vector" src="assets/vectors/Vector28_x2.svg" />
    </div>
  )
}